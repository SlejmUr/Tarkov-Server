import json

# json string
jsonStr = open('customisation.json', 'r').read()

# parse json file
pythonObj = json.loads(jsonStr)

for x in pythonObj:
    print(x)
    jsonString = json.dumps(pythonObj[x], indent = 2, separators=(',', ': '))
    jsonFile = open("export/" + x+".json", "w")
    jsonFile.write(jsonString)
    jsonFile.close()
